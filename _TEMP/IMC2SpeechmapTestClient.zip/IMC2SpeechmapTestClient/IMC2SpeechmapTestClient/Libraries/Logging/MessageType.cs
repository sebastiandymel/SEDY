﻿namespace IMC2SpeechmapTestClient.Libraries.Logging
{
    public enum MessageType
    {
        Sent,
        Received,
        Internal
    }
}
