﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;

namespace IMC2SpeechmapTestClient.Libraries.Logging
{
    public class LoggingManager
    {
        #region Singleton

        private static LoggingManager self;

        public static LoggingManager GetLoggingManager() => LoggingManager.self = LoggingManager.self ?? new LoggingManager();

        #endregion

        #region Constructor

        private LoggingManager()
        {
        }

        #endregion

        #region Public interface
        public string Log(UserMessage message)
        {
            lock (this.singleAccessLock)
            {
                message.Guid = Guid.NewGuid().ToString();
                LogMessages.Insert(0, message);
                if (this.saveAllMessagesToAFile)
                {
                    LogMessageToFile(message.Guid);
                }

                return message.Guid;
            }
        }

        private readonly object singleAccessLock = new object();
        public void LogMessageToFile(string userMessageGuid)
        {
            lock (this.singleAccessLock)
            {
                if (userMessageGuid == null || LogMessages.All(a => a.Guid != userMessageGuid))
                {
                    return;
                }

                UserMessage userMessage = LogMessages.Single(a => a.Guid == userMessageGuid);

                string filePath = CreateOrOpenLogFile();
                using (StreamWriter tw = File.AppendText(filePath))
                {
                    tw.WriteLine(userMessage.Time.ToString("T") + ": " + userMessage.Header);
                    tw.WriteLine(this.indent + userMessage.Message);
                    foreach (var userMessageDetail in userMessage.Details)
                    {
                        if (string.IsNullOrWhiteSpace(userMessageDetail.Item1) && string.IsNullOrWhiteSpace(userMessageDetail.Item1))
                        {
                            continue;
                        }

                        string text = string.Empty;
                        if (!string.IsNullOrWhiteSpace(userMessageDetail.Item1))
                        {

                            text = userMessageDetail.Item1.Replace(Environment.NewLine, ", ") + ": ";
                        }

                        text += userMessageDetail.Item2.Length > 20 ? Environment.NewLine + userMessageDetail.Item2 : userMessageDetail.Item2;
                        text = text.Replace(Environment.NewLine, Environment.NewLine + this.indent);
                        tw.WriteLine(this.indent + text);
                        tw.WriteLine();
                    }

                    tw.WriteLine();
                    tw.Close();
                }

                userMessage.IsSaved = true;
            }
        }

        public void ClearLogs()
        {
            lock (this.singleAccessLock)
            {
                LogMessages.Clear();
            }
        }

        public ObservableCollection<UserMessage> GetLogMessagesReference() => LogMessages;

        public void AddUserMessageDetails(string userMessageGuid, Tuple<string, string> details)
        {
            lock (this.singleAccessLock)
            {
                if (userMessageGuid == null || LogMessages.All(a => a.Guid != userMessageGuid))
                {
                    return;
                }

                var userMessage = LogMessages.Single(a => a.Guid == userMessageGuid);
                Application.Current.Dispatcher.Invoke(() =>
                {
                    userMessage.Details.Add(details);
                    userMessage.Counter++;
                    if (this.saveAllMessagesToAFile)
                    {
                        LogLastAddedDetailsToFile(userMessageGuid);
                    }
                });
            }
        }

        public void NewSession() => this.sessionTime = DateTime.Now;

        public void SaveAllMessagesToAFile(bool value)
        {
            lock (this.singleAccessLock)
            {
                this.saveAllMessagesToAFile = value;
            }
        }

        #endregion


        #region Private methods

        private string CreateOrOpenLogFile()
        {
            string directoryPath = Path.Combine(Directory.GetCurrentDirectory(), "Logs");
            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }

            string filePath = Path.Combine(directoryPath, this.sessionTime.ToString("dd-MM-yyyy HH.mm.ss") + "-log.txt");
            if (!File.Exists(filePath))
            {
                File.Create(filePath).Close();
            }

            return filePath;
        }

        private void LogLastAddedDetailsToFile(string userMessageGuid)
        {
            if (userMessageGuid == null || LogMessages.All(a => a.Guid != userMessageGuid))
            {
                return;
            }

            UserMessage userMessage = LogMessages.Single(a => a.Guid == userMessageGuid);

            string filePath = CreateOrOpenLogFile();
            string indent = "".PadLeft(10);
            using (StreamWriter tw = File.AppendText(filePath))
            {
                var userMessageDetail = userMessage.Details.Last();
                if (string.IsNullOrWhiteSpace(userMessageDetail.Item1) && string.IsNullOrWhiteSpace(userMessageDetail.Item1))
                {
                    tw.WriteLine();
                    tw.Close();
                    return;
                }

                tw.WriteLine(userMessage.Time.ToString("T") + ": " + userMessage.Header);
                tw.WriteLine(indent + "Message details received");
                string text = string.Empty;
                if (!string.IsNullOrWhiteSpace(userMessageDetail.Item1))
                {
                    text = userMessageDetail.Item1.Replace(Environment.NewLine, ", ") + ": ";
                }

                text += userMessageDetail.Item2.Length > 20 ? Environment.NewLine + userMessageDetail.Item2 : userMessageDetail.Item2;
                tw.WriteLine(indent + text);
                tw.WriteLine();
                tw.Close();
            }
        }

        #endregion


        #region Private fields and properties

        private DateTime sessionTime = DateTime.Now;

        private ObservableCollection<UserMessage> LogMessages { get; } = new ObservableCollection<UserMessage>();

        private bool saveAllMessagesToAFile;

        private readonly string indent = "".PadLeft(10);

        #endregion
    }
}
