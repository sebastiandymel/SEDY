﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using IMC2SpeechmapTestClient.ViewModels;

namespace IMC2SpeechmapTestClient.Libraries.Logging
{
    /// <summary>
    /// Interaction logic for LogTile.xaml
    /// </summary>
    public partial class LogTile : UserControl
    {
        public LogTile()
        {
            InitializeComponent();
        }

        private void Border_OnMouseDown(object sender, MouseButtonEventArgs e)
        {
            var mainWindow = Window.GetWindow(this);
            if (!(mainWindow?.DataContext is MainWindowViewModel mainWindowViewModel))
                return;

            var messageGuid = (DataContext as UserMessage)?.Guid;
            mainWindowViewModel.ShowMessageDetails(messageGuid);
        }
    }
}
