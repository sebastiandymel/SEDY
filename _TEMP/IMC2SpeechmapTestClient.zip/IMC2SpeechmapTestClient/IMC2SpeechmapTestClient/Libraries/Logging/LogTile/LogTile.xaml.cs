﻿using System;
using System.Windows.Controls;

namespace IMC2SpeechmapTestClient.Libraries.Logging
{
    /// <summary>
    /// Interaction logic for LogTile.xaml
    /// </summary>
    public partial class LogTile : UserControl
    {
        public LogTile()
        {
            InitializeComponent();
        }
    }
}
