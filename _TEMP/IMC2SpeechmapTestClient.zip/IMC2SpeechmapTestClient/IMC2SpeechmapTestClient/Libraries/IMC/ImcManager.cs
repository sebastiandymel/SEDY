﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Himsa.IMC2.DataDefinitions;
using IMC2SpeechmapTestClient.Libraries.Events.EventArgs;
using IMC2SpeechmapTestClient.Libraries.IMC.DataTypes;
using IMC2SpeechmapTestClient.Libraries.Logging;
using IMC2SpeechmapTestClient.Libraries.OfficeSystem.OfficeSystemManagers;
using IMC2SpeechmapTestClient.Libraries.View;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace IMC2SpeechmapTestClient.Libraries.IMC
{
    public class ImcManager
    {
        #region Singleton

        private static ImcManager self;

        public static ImcManager GetImcManager() => ImcManager.self = ImcManager.self ?? new ImcManager();

        #endregion

        #region Constructor

        private ImcManager()
        {
        }

        #endregion


        #region Public interface

        public void SubscribeToOfficeSystemEvents(IOfficeSystemManager officeSystemManager)
        {
            if (officeSystemManager == null)
            {
                ImcClient = null;
                ImcServerEx = null;
                return;
            }

            if (officeSystemManager is IImcClientProvider clientProvider)
            {
                ImcClient = clientProvider.GetImcClient();
                clientProvider.ImcClientChangedEvent += UpdateImcClient;
            }

            if (officeSystemManager is IImcServerExProvider serverExProvider)
            {
                ImcServerEx = serverExProvider.GetImcServerEx();
                serverExProvider.ImcServerExChangedEvent += UpdateImcServerEx;
            }
        }

        public void UnsubscribeFromOfficeSystemEvents(IOfficeSystemManager officeSystemManager)
        {
            if (officeSystemManager == null)
                return;

            if (officeSystemManager is IImcClientProvider clientProvider)
            {
                clientProvider.ImcClientChangedEvent -= UpdateImcClient;
            }

            if (officeSystemManager is IImcServerExProvider serverExProvider)
            {
                serverExProvider.ImcServerExChangedEvent -= UpdateImcServerEx;
            }
        }

        public MeasurementType GetLastMeasurementType() => this.lastMeasurementType;

        #endregion


        #region Imc communication commands

        public ImcCommandResult SetProtocolNo()
        {
            if (ImcServerEx == null)
                return GetCommandResult(IMC2RetParam.OcerCommunication);

            // Prepare data
            object data = null;
            string sentJson = JsonConvert.SerializeObject(data);
            int result = (int)IMC2RetParam.OcerError;

            // Send
            ImcServerEx?.CommandEx((int)IMCCommandEnum.oc_SetProtocolNo, (int)IMC2CmdParamProtocolNo.Protocol2, ref data, ref result);
            string resultJson = JsonConvert.SerializeObject((IMC2RetParam)result);
            string receivedJson = JsonConvert.SerializeObject(data);
            var commandResult = GetCommandResult((IMC2RetParam)result);

            // Log
            UserMessage userMessage = CreateCommandSentUserMessage(commandResult, "SetProtocolNo");
            userMessage.Details.Add(new Tuple<string, string>(this.imcSettingsManager.GetSettingLabel(SettingKey.ProtocolNumber), this.imcSettingsManager.GetSelectedSettingOption(SettingKey.ProtocolNumber)));
            string label = "Response:" + Environment.NewLine + "Sent data:" + Environment.NewLine + "Received data:";
            string description = resultJson + Environment.NewLine + sentJson + Environment.NewLine + receivedJson;
            userMessage.Details.Add(new Tuple<string, string>(label, description));
            this.loggingManager.Log(userMessage);

            return commandResult;
        }

        public ImcCommandResult PrepareSystem()
        {
            if (ImcServerEx == null)
                return GetCommandResult(IMC2RetParam.OcerCommunication);

            // Prepare data
            object data = new PrepareSystem
            {
                UIStatus = ShowModePrepareSystem.NoUI,
                SubSystem = SubSystemPrepareSystem.RealEar
            };
            string sentJson = JsonConvert.SerializeObject(data);
            int result = (int)IMC2RetParam.OcerError;

            // Send
            ImcServerEx?.CommandEx((int)IMCCommandEnum.ic_PrepareSystem, 0, ref data, ref result);
            string resultJson = JsonConvert.SerializeObject((IMC2RetParam)result);
            string receivedJson = JsonConvert.SerializeObject(data);
            var commandResult = GetCommandResult(IMC2RetParam.OcerOk);

            // Log
            UserMessage userMessage = CreateCommandSentUserMessage(commandResult, "PrepareSystem");
            string label = "Response:" + Environment.NewLine + "Sent data:" + Environment.NewLine + "Received data:";
            string description = resultJson + Environment.NewLine + sentJson + Environment.NewLine + receivedJson;
            userMessage.Details.Add(new Tuple<string, string>(label, description));
            this.loggingManager.Log(userMessage);

            return commandResult;
        }

        public ImcCommandResult ShowModule()
        {
            if (ImcServerEx == null)
                return GetCommandResult(IMC2RetParam.OcerCommunication);

            // Prepare data
            var showMode = (ShowMode)this.imcSettingsManager.GetSettingValue(SettingKey.ShowMode);
            object data = new ShowModuleEX { ShowMode = showMode };
            string sentJson = JsonConvert.SerializeObject(data);
            int result = (int)IMC2RetParam.OcerError;

            // Send
            ImcServerEx?.CommandEx((int)IMCCommandEnum.oc_ShowModule, 0, ref data, ref result);
            string resultJson = JsonConvert.SerializeObject((IMC2RetParam)result);
            string receivedJson = JsonConvert.SerializeObject(data);
            var commandResult = GetCommandResult((IMC2RetParam)result);

            // Log
            UserMessage userMessage = CreateCommandSentUserMessage(commandResult, "ShowModule");
            userMessage.Details.Add(new Tuple<string, string>("Show mode", showMode.ToString()));

            string label = "Response:" + Environment.NewLine + "Sent data:" + Environment.NewLine + "Received data:";
            string description = resultJson + Environment.NewLine + sentJson + Environment.NewLine + receivedJson;
            userMessage.Details.Add(new Tuple<string, string>(label, description));

            this.loggingManager.Log(userMessage);

            return commandResult;
        }

        public ImcCommandResult PerformProbeTubeCalibration()
        {
            if (ImcServerEx == null)
                return GetCommandResult(IMC2RetParam.OcerCommunication);

            // Prepare data
            var side = (TSide)this.imcSettingsManager.GetSettingValue(SettingKey.Side);
            var showMode = (ShowMode) this.imcSettingsManager.GetSettingValue(SettingKey.ShowMode);
            object data = new ProbeCalibration
            {
                Side = side,
                UIStatus = showMode
            };
            string sentJson = JsonConvert.SerializeObject(data);
            int result = (int)IMC2RetParam.OcerError;

            // Send
            ImcServerEx?.CommandEx((int)IMCCommandEnum.ic_ProbeCalibration, 0, ref data, ref result);
            string resultJson = JsonConvert.SerializeObject((IMC2RetParam)result);
            string receivedJson = JsonConvert.SerializeObject(data);
            var commandResult = GetCommandResult((IMC2RetParam)result);

            // Log
            UserMessage userMessage = CreateCommandSentUserMessage(commandResult, "ProbeTubeCalibration");
            userMessage.Details.Add(new Tuple<string, string>(this.imcSettingsManager.GetSettingLabel(SettingKey.Side), side.ToString()));
            userMessage.Details.Add(new Tuple<string, string>(this.imcSettingsManager.GetSettingLabel(SettingKey.ShowMode), showMode.ToString()));

            string label = "Response:" + Environment.NewLine + "Sent data:" + Environment.NewLine + "Received data:";
            string description = resultJson + Environment.NewLine + sentJson + Environment.NewLine + receivedJson;
            userMessage.Details.Add(new Tuple<string, string>(label, description));

            this.loggingManager.Log(userMessage);

            return commandResult;
        }

        public ImcCommandResult SetRearMeasurementConditions()
        {
            if (ImcServerEx == null)
                return GetCommandResult(IMC2RetParam.OcerCommunication);

            // Prepare data
            TMeasurementIdentification measurementIdentification;
            TSignalType signalType;
            string signalLevelOption = this.imcSettingsManager.GetSelectedSettingOption(SettingKey.RearSignalLevel);
            switch (signalLevelOption)
            {
                case "MPO":
                    measurementIdentification = TMeasurementIdentification.MPOmeasurement;
                    signalType = TSignalType.Tone;
                    break;

                default:
                    measurementIdentification = DefaultMandatoryRearConditions.MeasurementIdentification;
                    signalType = DefaultMandatoryRearConditions.SignalType;
                    break;
            }

            var side = (TSide) this.imcSettingsManager.GetSettingValue(SettingKey.Side);
            var signalLevel = (int) this.imcSettingsManager.GetSettingValue(SettingKey.RearSignalLevel);
            var averagingTime = (int)this.imcSettingsManager.GetSettingValue(SettingKey.RearAveragingTime);

            object data = new MeasurementConditions
            {
                AveragingTime = averagingTime,
                AveragingType = TAveragingType.LTASS, // diff
                CouplerAdapter = TCouplerAdapter.None,
                CouplerType = TCouplerType.Undefined,
                Date = DateTime.Now,
                DevTypeCode = 0,
                EarPiece = TEarPiece.None,
                FreeFieldAngle = 0,
                MLECorrection = TMLECorrection.Undefined,
                ManufactureCode = 0,
                MeasurementIdentification = measurementIdentification, // diff //***
                MeasurementMode = TMeasurementMode.Undefined,
                MeasurementResolution = DefaultMandatoryRearConditions.MeasurementResolution, //***
                ModuleID = 0,
                Percentiles = new[] {30, 99},
                ReferenceMicrophonePostion = TReferenceMicrophonePosition.Head,
                Side = side, //***
                SignalDuration = DefaultMandatoryRearConditions.SignalDuration, // diff //***
                SignalFrequencyRange = null,
                SignalLevel = signalLevel, // diff //***
                SignalOutput = TSignalOutput.Undefined,
                SignalType = signalType, //***
                TransducerId = "???",
                TransducerType = DefaultMandatoryRearConditions.TransducerType, //***????
                VocalEffort = TVocalEffort.None
            };
            string sentJson = JsonConvert.SerializeObject(data);
            int result = (int)IMC2RetParam.OcerError;

            // Send
            ImcServerEx?.CommandEx((int)IMCCommandEnum.ic_SetMeasurementConditions, 0, ref data, ref result);
            string resultJson = JsonConvert.SerializeObject((IMC2RetParam)result);
            string receivedJson = JsonConvert.SerializeObject(data);
            var commandResult = GetSetRearMeasurementConditionsCommandResult((MeasurementConditions)data);

            // Log
            UserMessage userMessage = CreateCommandSentUserMessage(commandResult, "SetRearMeasurementConditions");

            StringBuilder label = new StringBuilder()
                .Append(this.imcSettingsManager.GetSettingLabel(SettingKey.Side))
                .Append(Environment.NewLine)
                .Append("Sent:")
                .Append(Environment.NewLine)
                .Append("Received:");
            StringBuilder description = new StringBuilder()
                .Append(Environment.NewLine)
                .Append(side)
                .Append(Environment.NewLine)
                .Append(((MeasurementConditions)data).Side);
            userMessage.Details.Add(new Tuple<string, string>(label.ToString(), description.ToString()));

            label.Clear()
                .Append(this.imcSettingsManager.GetSettingLabel(SettingKey.RearSignalLevel))
                .Append(Environment.NewLine)
                .Append("Sent:")
                .Append(Environment.NewLine)
                .Append("Received:");
            description.Clear()
                .Append(Environment.NewLine)
                .Append(signalLevel)
                .Append(Environment.NewLine)
                .Append(((MeasurementConditions)data).SignalLevel);
            userMessage.Details.Add(new Tuple<string, string>(label.ToString(), description.ToString()));

            label.Clear()
                .Append(this.imcSettingsManager.GetSettingLabel(SettingKey.RearAveragingTime))
                .Append(Environment.NewLine)
                .Append("Sent:")
                .Append(Environment.NewLine)
                .Append("Received:");
            description.Clear()
                .Append(Environment.NewLine)
                .Append(averagingTime)
                .Append(Environment.NewLine)
                .Append(((MeasurementConditions)data).AveragingTime);
            userMessage.Details.Add(new Tuple<string, string>(label.ToString(), description.ToString()));

            label.Clear()
                .Append(this.imcSettingsManager.GetSettingLabel(SettingKey.SignalType))
                .Append(Environment.NewLine)
                .Append("Sent:")
                .Append(Environment.NewLine)
                .Append("Received:");
            description.Clear()
                .Append(Environment.NewLine)
                .Append(signalType)
                .Append(Environment.NewLine)
                .Append(((MeasurementConditions)data).SignalType);
            userMessage.Details.Add(new Tuple<string, string>(label.ToString(), description.ToString()));

            label.Clear()
                .Append(this.imcSettingsManager.GetSettingLabel(SettingKey.MeasurementIdentification))
                .Append(Environment.NewLine)
                .Append("Sent:")
                .Append(Environment.NewLine)
                .Append("Received:");
            description.Clear()
                .Append(Environment.NewLine)
                .Append(measurementIdentification)
                .Append(Environment.NewLine)
                .Append(((MeasurementConditions)data).MeasurementIdentification);
            userMessage.Details.Add(new Tuple<string, string>(label.ToString(), description.ToString()));

            label.Clear()
                .Append("Response:")
                .Append(Environment.NewLine)
                .Append("Sent data:")
                .Append(Environment.NewLine)
                .Append("Received data:");
            description.Clear()
                .Append(sentJson)
                .Append(Environment.NewLine)
                .Append(receivedJson);
            userMessage.Details.Add(new Tuple<string, string>(label.ToString(), description.ToString()));

            this.loggingManager.Log(userMessage);

            return commandResult;
        }

        public ImcCommandResult PerformRearMeasurement()
        {
            if (ImcServerEx == null)
                return GetCommandResult(IMC2RetParam.OcerCommunication);

            // Prepare data
            object data = null;
            int result = (int)IMC2RetParam.OcerError;
            string sentJson = JsonConvert.SerializeObject(data);

            // Send
            ImcServerEx?.CommandEx((int)IMCCommandEnum.ic_StartMeasurement, 0, ref data, ref result);
            string resultJson = JsonConvert.SerializeObject((IMC2RetParam)result);
            string receivedJson = JsonConvert.SerializeObject(data);
            this.lastMeasurementType = MeasurementType.Rear;
            var commandResult = GetCommandResult((IMC2RetParam)result);

            // Log
            UserMessage userMessage = CreateCommandSentUserMessage(commandResult, "RearMeasurement");
            string label = "Response:" + Environment.NewLine + "Sent data:" + Environment.NewLine + "Received data:";
            string description = resultJson + Environment.NewLine + sentJson + Environment.NewLine + receivedJson;
            userMessage.Details.Add(new Tuple<string, string>(label, description));
            this.loggingManager.Log(userMessage);

            return commandResult;
        }

        #endregion


        #region Events

        public event EventHandler<SystemPreparedEventArgs> SystemPreparedEvent;

        public event EventHandler<HeartBeatOccuredEventArgs> HeartBeatEvent;

        public event EventHandler<SweepEndedEventArgs> SweepEndedEvent;

        public event EventHandler<SweepEndedEventArgs> MeasurementEndedEvent;

        public event EventHandler<ProbeTubeCalibrationEndedEventArgs> ProbeTubeCalibrationEndedEvent;

        #endregion


        #region #### Private fields and properties

        private ImcClient imcClient;
        private ImcClient ImcClient
        {
            get => this.imcClient;
            set
            {
                this.imcClient = value;

                this.imcClient?.SetDataReadyCallbacks(
                    new Dictionary<DataReadyType, Action<DataReady>>
                    {
                        { DataReadyType.HeartBeat, HeartBeatCallback },
                        { DataReadyType.MeasurementEnded, MeasurementEndedCallback },
                        { DataReadyType.SweepEnded, SweepEndedCallback },
                        { DataReadyType.PropeCalibrationEnded, ProbeTubeCalibrationEndedCallback },
                        { DataReadyType.PrepareSystemEnded, SystemPreparedCallback }
                    });
            }
        }

        private ImcServerEx imcServerEx;

        private ImcServerEx ImcServerEx
        {
            get => this.imcServerEx;
            set
            {
                this.imcServerEx = value;
                if (this.imcServerEx == null)
                    return;


                // TODO: Tie up event handlers
            }
        }

        private MeasurementType lastMeasurementType = MeasurementType.None;

        private readonly ImcSettingsManager imcSettingsManager = ImcSettingsManager.GetImcSettingsManager();

        private readonly LoggingManager loggingManager = LoggingManager.GetLoggingManager();

        #endregion


        #region Imc communication responses

        private void HeartBeatCallback(DataReady dataReady)
        {
            var eventArgs = new HeartBeatOccuredEventArgs(
                new HeartBeatData
                {
                    Time = DateTime.Now
                });

            HeartBeatEvent?.Invoke(this, eventArgs);
        }

        private void MeasurementEndedCallback(DataReady dataReady)
        {
            var siis = ExtractSii(dataReady.StatusText);
            var eventArgs = new SweepEndedEventArgs(
                new SweepEndedData
                {
                    Side = SideToMeasurementSide(dataReady.Side),
                    AidedSii = siis?.AidedSii,
                    UnaidedSii = siis?.UnaidedSii,
                    Data = dataReady.Data,
                    Json = JsonConvert.SerializeObject(dataReady)
                });

            MeasurementEndedEvent?.Invoke(this, eventArgs);
        }

        private void SweepEndedCallback(DataReady dataReady)
        {
            var siis = ExtractSii(dataReady.StatusText);
            var eventArgs = new SweepEndedEventArgs(
                new SweepEndedData
                {
                    Side = SideToMeasurementSide(dataReady.Side),
                    AidedSii = siis?.AidedSii,
                    UnaidedSii = siis?.UnaidedSii,
                    Data = dataReady.Data
                });

            SweepEndedEvent?.Invoke(this, eventArgs);
        }

        private void ProbeTubeCalibrationEndedCallback(DataReady dataReady)
        {
            var eventArgs = new ProbeTubeCalibrationEndedEventArgs(
                new ProbetubeCalibrationEndedData
                {
                    Json = JsonConvert.SerializeObject(dataReady)
                });

            ProbeTubeCalibrationEndedEvent?.Invoke(this, eventArgs);
        }

        private void SystemPreparedCallback(DataReady dataReady)
        {
            var eventArgs = new SystemPreparedEventArgs(
                new SystemPreparedData
                {
                    Json = JsonConvert.SerializeObject(dataReady)
                });

            SystemPreparedEvent?.Invoke(this, eventArgs);
        }

        #endregion


        #region #### Private methods

        private void UpdateImcClient(object sender, ImcClientChangedEventArgs e)
        {
            ImcClient = e.Data;
        }

        private void UpdateImcServerEx(object sender, ImcServerExChangedEventArgs e)
        {
            ImcServerEx = e.Data;
        }

        private static ImcCommandResult GetCommandResult(IMC2RetParam result)
        {
            switch (result)
            {
                case IMC2RetParam.OcerCalibrationMissing:
                case IMC2RetParam.OcerCommunication:
                case IMC2RetParam.OcerError:
                case IMC2RetParam.OcerNotShown:
                    return ImcCommandResult.Error;

                case IMC2RetParam.OcerOk:
                case IMC2RetParam.OcerRunning:
                case IMC2RetParam.OcerShown:
                    return ImcCommandResult.Success;

                case IMC2RetParam.OcerOther:
                case IMC2RetParam.OcerNotSupported:
                    return ImcCommandResult.Warning;

                default:
                    return ImcCommandResult.Error;
            }
        }

        private ImcCommandResult GetSetRearMeasurementConditionsCommandResult(MeasurementConditions received)
        {
            bool areUnchangebleConditionsMet =
                (TSide) this.imcSettingsManager.GetSettingValue(SettingKey.Side) == received.Side
                && (int) this.imcSettingsManager.GetSettingValue(SettingKey.RearSignalLevel) == received.SignalLevel
                && DefaultMandatoryRearConditions.MeasurementIdentification == received.MeasurementIdentification
                && DefaultMandatoryRearConditions.MeasurementResolution == received.MeasurementResolution
                && DefaultMandatoryRearConditions.SignalDuration == received.SignalDuration
                && DefaultMandatoryRearConditions.SignalType == received.SignalType
                && DefaultMandatoryRearConditions.TransducerType == received.TransducerType;

            IEnumerable<int> twoFirstPercentiles = received.Percentiles.Length >= 2 ? received.Percentiles.Take(2).ToList() : new List<int>();
            bool areDefaultPercentilesSet = twoFirstPercentiles.Contains(30) && twoFirstPercentiles.Contains(99);

            if (!areUnchangebleConditionsMet)
            {
                return ImcCommandResult.Error;
            }

            return !areDefaultPercentilesSet ? ImcCommandResult.Warning : ImcCommandResult.Success;
        }

        private static SiiData ExtractSii(string json)
        {
            if (string.IsNullOrWhiteSpace(json))
            {
                return new SiiData();
            }

            try
            {
                var jObject = JObject.Parse(json);
                var sideToken = jObject?.Root?.SelectToken("result")?.SelectToken("side");
                if (sideToken == null)
                {
                    return new SiiData();
                }

                var leftSiiToken = sideToken.SelectToken("left")?.SelectToken("sii");
                var rightSiiToken = sideToken.SelectToken("right")?.SelectToken("sii");

                var siiData = new SiiData
                {
                    AidedSii =
                    {
                        Left = leftSiiToken?.SelectToken("aided")?.Value<int?>(),
                        Right = rightSiiToken?.SelectToken("aided")?.Value<int?>()
                    },
                    UnaidedSii =
                    {
                        Left = leftSiiToken?.SelectToken("unaided")?.Value<int?>(),
                        Right = rightSiiToken?.SelectToken("unaided")?.Value<int?>()
                    }
                };


                return siiData;
            }
            catch
            {
                return new SiiData();
            }
        }

        private static MeasurementSide SideToMeasurementSide(TSide side)
        {
            switch (side)
            {
                case TSide.Left:
                    return MeasurementSide.Left;
                case TSide.Right:
                    return MeasurementSide.Right;
                case TSide.Binaural:
                    return MeasurementSide.Both;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

        private static UserMessage CreateCommandSentUserMessage(ImcCommandResult result, string commandName)
        {
            switch (result)
            {
                case ImcCommandResult.Success:
                    return new UserMessage
                    {
                        MessageType = MessageType.Sent,
                        ControlState = ControlState.Success,
                        Header = commandName,
                        Message = commandName + " command sent with success"
                    };

                case ImcCommandResult.Warning:
                    return new UserMessage
                    {
                        MessageType = MessageType.Sent,
                        ControlState = ControlState.Warning,
                        Header = commandName,
                        Message = commandName + " command sent with warning"
                    };

                default:
                    return new UserMessage
                    {
                        MessageType = MessageType.Sent,
                        ControlState = ControlState.Error,
                        Header = commandName,
                        Message = commandName + " command sent with error"
                    };
            }
        }

        #endregion
    }
}
