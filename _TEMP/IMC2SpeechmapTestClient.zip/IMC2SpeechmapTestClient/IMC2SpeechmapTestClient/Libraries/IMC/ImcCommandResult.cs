﻿namespace IMC2SpeechmapTestClient.Libraries.IMC
{
    public enum ImcCommandResult
    {
        Error,
        Warning,
        Success
    }
}
