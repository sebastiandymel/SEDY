﻿namespace IMC2SpeechmapTestClient.Libraries.IMC.DataTypes
{
    public class ProbetubeCalibrationEndedData
    {
    }
}
