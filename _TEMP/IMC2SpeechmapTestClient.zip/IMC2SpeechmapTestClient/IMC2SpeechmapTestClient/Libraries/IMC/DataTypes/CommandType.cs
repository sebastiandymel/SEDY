﻿namespace IMC2SpeechmapTestClient.Libraries.IMC.DataTypes
{
    public enum CommandType
    {
        ShowModule,
        PerformProbeTubeCalibration,
        RearMeasurement,
    }
}
