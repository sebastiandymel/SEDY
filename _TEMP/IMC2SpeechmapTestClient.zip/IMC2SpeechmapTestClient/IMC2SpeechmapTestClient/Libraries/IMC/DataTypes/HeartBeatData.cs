﻿using System;

namespace IMC2SpeechmapTestClient.Libraries.IMC.DataTypes
{
    public class HeartBeatData
    {
        public DateTime Time { get; set; }
    }
}
