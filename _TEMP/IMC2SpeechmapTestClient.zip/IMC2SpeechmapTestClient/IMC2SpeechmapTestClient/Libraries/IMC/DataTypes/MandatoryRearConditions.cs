﻿using Himsa.IMC2.DataDefinitions;

namespace IMC2SpeechmapTestClient.Libraries.IMC.DataTypes
{
    public static class DefaultMandatoryRearConditions
    {
        public static readonly TMeasurementIdentification MeasurementIdentification = TMeasurementIdentification.AidedResponse;

        public static readonly TMeasurementResolution MeasurementResolution = TMeasurementResolution.OneThirdOctave;

        public static readonly int SignalDuration = 15;

        public static readonly TSignalType SignalType = TSignalType.ISTS;

        public static readonly TTransducerType TransducerType = TTransducerType.Speaker;
    }
}
