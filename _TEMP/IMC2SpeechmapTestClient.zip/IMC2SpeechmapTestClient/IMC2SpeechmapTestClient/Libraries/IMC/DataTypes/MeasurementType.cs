﻿namespace IMC2SpeechmapTestClient.Libraries.IMC.DataTypes
{
    public enum MeasurementType
    {
        None,
        Reur,
        Rear
    }
}
