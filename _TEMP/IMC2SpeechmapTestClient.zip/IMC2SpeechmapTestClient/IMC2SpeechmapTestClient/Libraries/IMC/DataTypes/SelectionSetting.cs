﻿using System;
using GalaSoft.MvvmLight;

namespace IMC2SpeechmapTestClient.Libraries.IMC.DataTypes
{
    public class SelectionSetting : ViewModelBase
    {
        public SelectionSetting(Action<string> onSelectedValueChanged)
        {
            this.onSelectedValueChanged = onSelectedValueChanged;
        }

        private readonly Action<string> onSelectedValueChanged;

        public string Label { get; set; }

        private string selectedValue;
        public string SelectedValue
        {
            get => this.selectedValue;
            set
            {
                this.selectedValue = value;
                this.onSelectedValueChanged?.Invoke(SelectedValue);
            }
        }

        public string[] Values { get; set; }
    }
}
