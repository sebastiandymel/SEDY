﻿namespace IMC2SpeechmapTestClient.Libraries.IMC.DataTypes
{
    public class SystemPreparedData
    {
        public string Json { get; set; }
    }
}
