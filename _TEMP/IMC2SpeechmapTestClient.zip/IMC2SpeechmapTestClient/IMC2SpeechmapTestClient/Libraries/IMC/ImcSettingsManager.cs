﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Himsa.IMC2.DataDefinitions;
using IMC2SpeechmapTestClient.Libraries.IMC.DataTypes;

namespace IMC2SpeechmapTestClient.Libraries.IMC
{
    public class ImcSettingsManager
    {
        #region Singleton

        private static ImcSettingsManager self;

        public static ImcSettingsManager GetImcSettingsManager() => ImcSettingsManager.self = ImcSettingsManager.self ?? new ImcSettingsManager();

        #endregion


        #region Constructor

        private ImcSettingsManager()
        {
        }

        #endregion


        #region Public interface

        public void SetSetting(SettingKey key, string value)
            => this.selectedOptionsDictionary[key] = value;

        public object GetSettingValue(SettingKey settingKey)
        {
            switch (settingKey)
            {
                case SettingKey.Side:
                    return GetSideValue();

                case SettingKey.RearSignalLevel:
                    return GetRearSignalLevelValue();

                case SettingKey.ShowMode:
                    return GetShowModeValue();

                case SettingKey.RearAveragingTime:
                    return GetRearAveragingTimeValue();

                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

        public string[] GetSettingOptions(SettingKey settingKey) => this.options.ContainsKey(settingKey)
            ? this.options[settingKey]
            : throw new ArgumentOutOfRangeException();

        public string GetSelectedSettingOption(SettingKey settingKey)
        {
            return this.selectedOptionsDictionary.ContainsKey(settingKey)
                ? this.selectedOptionsDictionary[settingKey]
                : this.defaultOptions.ContainsKey(settingKey)
                    ? this.defaultOptions[settingKey]
                    : throw new ArgumentOutOfRangeException();
        }

        public SettingKey[] GetSettingKeys(CommandType commandType) => this.settingKeys.ContainsKey(commandType)
            ? this.settingKeys[commandType]
            : null;

        public string GetSettingLabel(SettingKey settingKey) =>
            this.settingLabels.ContainsKey(settingKey)
                ? this.settingLabels[settingKey]
                : throw new ArgumentOutOfRangeException();

        public void ClearSelectedSettings() => this.selectedOptionsDictionary.Clear();

        public TMeasurementIdentification GetMeasurementIdentificationValue(TMeasurementIdentification defaultValue)
        {
            if (this.selectedOptionsDictionary.ContainsKey(SettingKey.RearSignalLevel) &&
                this.selectedOptionsDictionary[SettingKey.RearSignalLevel] == "MPO")
                return TMeasurementIdentification.MPOmeasurement;

            return defaultValue;
        }

        #endregion


        #region Private fields and properties

        private readonly Dictionary<SettingKey, string[]> options = new Dictionary<SettingKey, string[]>
        {
            { SettingKey.ProtocolNumber, new[] { "1", "2" } },
            { SettingKey.RearSignalLevel, new[] { "50", "65", "80", "MPO" } },
            { SettingKey.Side, new[] { TSide.Left.ToString(), TSide.Right.ToString(), TSide.Binaural.ToString() } },
            { SettingKey.ShowMode, new[] { ShowMode.FullUI.ToString(), ShowMode.BasicUI.ToString(), ShowMode.NoUI.ToString(), ShowMode.ReducedUI.ToString() } },
            { SettingKey.RearAveragingTime, new[] { "0", "100", "1 000", "10 000", "100 000", "1 000 000", "10 000 000", "100 000 000", "1 000 000 000", "Default (2 147 483 647)" } }
        };

        private readonly Dictionary<SettingKey, string> defaultOptions = new Dictionary<SettingKey, string>
        {
            { SettingKey.ProtocolNumber, "2" },
            { SettingKey.RearSignalLevel, "50" },
            { SettingKey.Side, TSide.Binaural.ToString() },
            { SettingKey.ShowMode, ShowMode.FullUI.ToString() },
            { SettingKey.RearAveragingTime, "Default (2 147 483 647)" }
        };

        private readonly Dictionary<CommandType, SettingKey[]> settingKeys = new Dictionary<CommandType, SettingKey[]>
        {
            { CommandType.RearMeasurement, new[] { SettingKey.Side, SettingKey.RearSignalLevel, SettingKey.RearAveragingTime } },
            { CommandType.ShowModule, new[] { SettingKey.ShowMode } },
            { CommandType.PerformProbeTubeCalibration, new[] { SettingKey.Side, SettingKey.ShowMode } }
        };

        private readonly Dictionary<SettingKey, string> settingLabels = new Dictionary<SettingKey, string>
        {
            { SettingKey.ProtocolNumber, "Protocol number" },
            { SettingKey.RearSignalLevel, "Signal Level" },
            { SettingKey.Side, "Side" },
            { SettingKey.ShowMode, "Show mode" },
            { SettingKey.RearAveragingTime, "Averaging time" },
            { SettingKey.MeasurementIdentification, "Measurement identification" },
            { SettingKey.SignalType, "Signal type" }
        };

        private readonly Dictionary<SettingKey, string> selectedOptionsDictionary = new Dictionary<SettingKey, string>();

        #endregion


        #region Private helpers

        private int GetRearSignalLevelValue()
        {
            if (!this.selectedOptionsDictionary.ContainsKey(SettingKey.RearSignalLevel))
                return ImcSettingsManager.DefaultRearSignalLevelValue;

            string rearSignalLevel = this.selectedOptionsDictionary[SettingKey.RearSignalLevel];
            switch (rearSignalLevel)
            {
                case "MPO":
                    return 90;

                case "50":
                case "65":
                case "80":
                    return int.Parse(rearSignalLevel);

                default:
                    return ImcSettingsManager.DefaultRearSignalLevelValue;
            }
        }

        private int GetRearAveragingTimeValue()
        {
            if (!this.selectedOptionsDictionary.ContainsKey(SettingKey.RearAveragingTime)
                || this.selectedOptionsDictionary[SettingKey.RearAveragingTime] ==
                this.defaultOptions[SettingKey.RearAveragingTime])
            {
                return ImcSettingsManager.DefaultRearAveragingTimeValue;
            }

            string rearSignalLevel = this.selectedOptionsDictionary[SettingKey.RearAveragingTime];
            return int.Parse(Regex.Replace(rearSignalLevel, @"\s+", string.Empty));
        }

        private TSide GetSideValue()
        {
            if (!this.selectedOptionsDictionary.ContainsKey(SettingKey.Side))
                return ImcSettingsManager.DefaultSide;

            string side = this.selectedOptionsDictionary[SettingKey.Side];
            switch (side)
            {
                case "Left":
                case "Right":
                case "Binaural":
                    return (TSide)Enum.Parse(typeof(TSide), side);

                default:
                    return ImcSettingsManager.DefaultSide;
            }
        }

        private ShowMode GetShowModeValue()
        {
            if (!this.selectedOptionsDictionary.ContainsKey(SettingKey.ShowMode))
                return ImcSettingsManager.DefaultShowMode;

            string showMode = this.selectedOptionsDictionary[SettingKey.ShowMode];
            switch (showMode)
            {
                case "FullUI":
                case "BasicUI":
                case "NoUI":
                case "ReducedUI":
                    return (ShowMode)Enum.Parse(typeof(ShowMode), showMode);

                default:
                    return ImcSettingsManager.DefaultShowMode;
            }
        }

        #endregion


        #region Default values

        private const int DefaultRearAveragingTimeValue = 2147483647;

        private const int DefaultRearSignalLevelValue = 50;

        private const TSide DefaultSide = TSide.Binaural;

        private const ShowMode DefaultShowMode = ShowMode.FullUI;

        #endregion
    }
}
