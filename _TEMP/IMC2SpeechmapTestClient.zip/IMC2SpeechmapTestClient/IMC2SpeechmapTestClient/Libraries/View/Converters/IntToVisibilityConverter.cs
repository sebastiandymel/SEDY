﻿using System;
using System.Windows;
using System.Windows.Data;

namespace IMC2SpeechmapTestClient.Libraries.View.Converters
{
    public class IntToVisibilityConverter: IValueConverter
    {
        /// <summary>Returns Visibility.Visible when a value is greater than zero</summary>
        /// <summary>Used for showing/hiding updates count on UserMessage Tile</summary>
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (!(value is int intValue))
                return Visibility.Hidden;

            return intValue <= 0 ? Visibility.Hidden : Visibility.Visible;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
