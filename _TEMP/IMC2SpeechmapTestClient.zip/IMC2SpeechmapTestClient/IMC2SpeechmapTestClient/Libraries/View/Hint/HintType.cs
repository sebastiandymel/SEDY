﻿namespace IMC2SpeechmapTestClient.Libraries.View
{
    public enum HintType
    {
        Info,
        Warning,
        Error
    }
}
