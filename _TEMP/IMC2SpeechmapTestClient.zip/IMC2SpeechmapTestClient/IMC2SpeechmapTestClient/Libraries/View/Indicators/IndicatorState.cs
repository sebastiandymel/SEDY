﻿namespace IMC2SpeechmapTestClient.Libraries.View
{
    public enum IndicatorState
    {
        Red,
        Yellow,
        Green
    }
}
