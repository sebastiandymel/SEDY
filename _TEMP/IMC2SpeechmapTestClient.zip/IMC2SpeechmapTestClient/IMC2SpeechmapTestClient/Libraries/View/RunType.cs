﻿namespace IMC2SpeechmapTestClient.Libraries.View
{
    public enum RunMode
    {
        Standalone,
        Noah,
        None
    }
}
