﻿namespace IMC2SpeechmapTestClient.Libraries.OfficeSystem.DataTypes
{
    public class HearingSoftwareProtocol
    {
        public HearingSoftwareDataType[] DataTypes { get; set; }

        public short Number { get; set; }
    }
}
