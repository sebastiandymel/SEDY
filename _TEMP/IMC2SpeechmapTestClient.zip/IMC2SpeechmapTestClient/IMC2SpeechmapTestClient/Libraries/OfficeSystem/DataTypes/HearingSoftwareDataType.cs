﻿namespace IMC2SpeechmapTestClient.Libraries.OfficeSystem.DataTypes
{
    public class HearingSoftwareDataType
    {
        public short Code { get; set; }
        public short Format { get; set; }
        public short FormatExt { get; set; }
    }
}
