﻿namespace IMC2SpeechmapTestClient.Libraries.OfficeSystem
{
    public class OfficeSystemData
    {
        public string Label { get; set; }

        public string OfficeSystemName { get; set; }
    }
}
