﻿using GalaSoft.MvvmLight;

namespace IMC2SpeechmapTestClient.Libraries.OfficeSystem
{
    public class OfficeSystemData : ViewModelBase
    {
        public string OfficeSystemName { get; set; }
    }
}
