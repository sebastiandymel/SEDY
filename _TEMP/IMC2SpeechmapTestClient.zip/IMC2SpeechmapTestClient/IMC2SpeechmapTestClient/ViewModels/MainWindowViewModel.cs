﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.CommandWpf;
using Himsa.IMC2.DataDefinitions;
using IMC2SpeechmapTestClient.Libraries.Events.EventArgs;
using IMC2SpeechmapTestClient.Libraries.IMC;
using IMC2SpeechmapTestClient.Libraries.IMC.DataTypes;
using IMC2SpeechmapTestClient.Libraries.Logging;
using IMC2SpeechmapTestClient.Libraries.OfficeSystem;
using IMC2SpeechmapTestClient.Libraries.OfficeSystem.DataTypes;
using IMC2SpeechmapTestClient.Libraries.OfficeSystem.OfficeSystemManagers;
using IMC2SpeechmapTestClient.Libraries.View;
using Microsoft.Practices.ObjectBuilder2;

namespace IMC2SpeechmapTestClient.ViewModels
{
    public class MainWindowViewModel : ViewModelBase
    {


        #region #### Initialization

        public static string Version { get; } = "  IMC2 Speechmap Client - 1.0.4";

        public MainWindowViewModel()
        {
            OfficeSystemData = this.noOfficeSystemData;
            InitializeViewCommands();
            InitializeImcCommands();
            CreateMenuItemsFromModules();
            StartIntervalTasks();
            SubscribeToImcManagerEvents();

            UserMessages = this.loggingManager.GetLogMessagesReference();
            BindingOperations.EnableCollectionSynchronization(UserMessages, new object());
            RefreshHint();
        }

        #endregion



        #region #### View-binded properties

        public MainWindowCommands ViewCommands { get; set; } = new MainWindowCommands();

        public ObservableCollection<ImcTestCommand> ImcCommands { get; } = new ObservableCollection<ImcTestCommand>();
        public Indicators Indicators { get; set; } = new Indicators();

        public Hint Hint
        {
            get => this.hint;
            set
            {
                this.hint = value;
                RaisePropertyChanged(nameof(MainWindowViewModel.Hint));
            }
        }

        public ObservableCollection<Control> ModulesMenuItems { get; set; } = new ObservableCollection<Control>();

        public ObservableCollection<UserMessage> UserMessages { get; set; }

        public bool CanSendNextCommandToRemSystem
        {
            get => this.canSendNextCommandToRemSystem;
            set
            {
                this.canSendNextCommandToRemSystem = value;
                RaisePropertyChanged(nameof(MainWindowViewModel.CanSendNextCommandToRemSystem));
                RefreshImcCommands();
            }
        }

        public ObservableCollection<SelectionSetting> SelectionSettings { get; set; } =
            new ObservableCollection<SelectionSetting>();

        public bool AreCommandSettingsVisible
        {
            get => this.areCommandSettingsVisible;
            private set
            {
                this.areCommandSettingsVisible = value;
                RaisePropertyChanged(nameof(MainWindowViewModel.AreCommandSettingsVisible));
            }
        }

        public bool SaveAllMessagesToAFile
        {
            get => this.saveAllMessagesToAFile;
            set
            {
                this.saveAllMessagesToAFile = value;
                this.loggingManager.SaveAllMessagesToAFile(value);
                RaisePropertyChanged(nameof(MainWindowViewModel.SaveAllMessagesToAFile));
            }

        }

        #endregion



        #region #### Private fields and properties

        private Hint hint;

        private LoggingManager loggingManager = LoggingManager.GetLoggingManager();

        private bool canSendNextCommandToRemSystem = true;

        private bool areCommandSettingsVisible;

        private string lastSweepEndedUserMessageGuid;

        private bool saveAllMessagesToAFile;

        #endregion



        #region #### Private methods

        private void InitializeViewCommands()
        {
            // General Commands
            ViewCommands.Quit = new RelayCommand(() => { this.officeSystemManager?.Disconnect(); Application.Current.Shutdown(); }, () => true);

            // Mode Commands
            ViewCommands.SetRunModeToStandalone = new RelayCommand(() => { RunMode = RunMode.Standalone; }, () => RunMode != RunMode.Standalone);
            ViewCommands.SetRunModeToNoah = new RelayCommand(() => { RunMode = RunMode.Noah; }, () => RunMode != RunMode.Noah);
            ViewCommands.SetRunModeToNone = new RelayCommand(() => { RunMode = RunMode.None; }, () => RunMode != RunMode.None);

            ViewCommands.RegisterMyselfInCurrentMode = new RelayCommand(() => { }, () => RunMode == RunMode.Noah);

            ViewCommands.LaunchRemModule = new RelayCommand(
                () => { this.officeSystemManager.LaunchRemModule(this.activeRemModule.ModuleName); },
                () => this.officeSystemManager != null && !this.officeSystemManager.IsConnectedToRemModule);

            ViewCommands.CloseRemModule = new RelayCommand(
                () => { this.officeSystemManager.CloseRemModule(); },
                () => this.officeSystemManager != null && this.officeSystemManager.IsConnectedToRemModule);

            ViewCommands.ClearLogs = new RelayCommand(() => { this.loggingManager.ClearLogs(); }, () => UserMessages != null && UserMessages.Any());

            ViewCommands.CloseSettings = new RelayCommand(HideImcSettings);

            ViewCommands.CloseDetails = new RelayCommand(HideDetails);

            ViewCommands.WriteMessageToLogFile = new RelayCommand(WriteWriteMessageToLogFile, () => !SaveAllMessagesToAFile && ActiveUserMessage?.IsSaved == false);

            ViewCommands.InvertSaveAllMessagesToAFile = new RelayCommand(() => SaveAllMessagesToAFile = !SaveAllMessagesToAFile, () => true);
        }

        private void InitializeImcCommands()
        {
            bool CanSendSetProtocolNoCommand()
            {
                return this.officeSystemManager?.IsConnectedToRemModule == true &&
                       Indicators.WasProtololNoSet != ControlState.Success;
            }
            var setProtocolNo = new ImcTestCommand(() =>
            {
                var result = this.imcManager.SetProtocolNo();
                Indicators.WasProtololNoSet = ImcCommandResultToControlState(result);
                return Indicators.WasProtololNoSet;
            }, CanSendSetProtocolNoCommand)
            {
                Id = CommandId.SetProtocolNo,
                Label = "Set Protocol Number",
                OpenSettingsCommand = new RelayCommand(() => { }, () => false)
            };
            ImcCommands.Add(setProtocolNo);


            bool CanSendPrepareSystemCommand()
            {
                return this.officeSystemManager?.IsConnectedToRemModule == true &&
                       Indicators.WasProtololNoSet == ControlState.Success &&
                       Indicators.WasPrepareSystemCommandSent != ControlState.Success;
            }
            var prepareSystem = new ImcTestCommand(() =>
            {
                var result = this.imcManager.PrepareSystem();
                Indicators.WasPrepareSystemCommandSent = ImcCommandResultToControlState(result);
                return Indicators.WasPrepareSystemCommandSent;
            }, CanSendPrepareSystemCommand)
            {
                Id = CommandId.PrepareSystem,
                Label = "Prepare System",
                OpenSettingsCommand = new RelayCommand(() => { }, () => false)
            };
            ImcCommands.Add(prepareSystem);


            bool CanSendShowmoduleCommand()
            {
                return this.officeSystemManager?.IsConnectedToRemModule == true &&
                       Indicators.WasPrepareSystemCommandSent == ControlState.Success &&
                       Indicators.WasModuleShowed != ControlState.Success;
            }
            var showModuleSettingsCommand = new RelayCommand(() =>
            {
                CreateImcSettings(CommandType.ShowModule);
                ShowImcSettings();
            }, CanSendShowmoduleCommand);
            var showModule = new ImcTestCommand(() =>
            {
                var result = this.imcManager.ShowModule();
                Indicators.WasModuleShowed = ImcCommandResultToControlState(result);
                return Indicators.WasModuleShowed;
            }, CanSendShowmoduleCommand)
            {
                Label = "Show Module",
                Id = CommandId.ShowModule,
                OpenSettingsCommand = showModuleSettingsCommand
            };
            ImcCommands.Add(showModule);


            bool CanSendPerformProbeTubeCalibrationCommand()
            {
                return CanSendNextCommandToRemSystem &&
                       this.officeSystemManager?.IsConnectedToRemModule == true &&
                       Indicators.WasModuleShowed == ControlState.Success ||
                       Indicators.WasModuleShowed == ControlState.Warning;
            }
            var performProbeTubeCalibrationSettingsCommand = new RelayCommand(() =>
            {
                CreateImcSettings(CommandType.PerformProbeTubeCalibration);
                ShowImcSettings();
            }, CanSendPerformProbeTubeCalibrationCommand);
            var performProbetubeCalibration = new ImcTestCommand(() =>
            {
                CanSendNextCommandToRemSystem = false;
                var result = this.imcManager.PerformProbeTubeCalibration();
                Indicators.WasProbeTubeCalibrationCommandSent = ImcCommandResultToControlState(result);
                Indicators.WasProbeTubeCalibrationPerformed = ControlState.Error;
                return Indicators.WasProbeTubeCalibrationCommandSent;
            }, CanSendPerformProbeTubeCalibrationCommand)
            {
                Label = "Probe Tube Calibration",
                Id = CommandId.ProbeTubeCalibration,
                OpenSettingsCommand = performProbeTubeCalibrationSettingsCommand
            };
            ImcCommands.Add(performProbetubeCalibration);


            bool CanSendPerformReurMeasurementCommand()
            {
                return false;
            }
            var reugMeasurement = new ImcTestCommand(() => { return ControlState.NotSet; }, CanSendPerformReurMeasurementCommand)
            {
                Id = CommandId.ReugMeasurement,
                Label = "Reug Measurement",
                OpenSettingsCommand = new RelayCommand(() => { }, () => false)
            };
            ImcCommands.Add(reugMeasurement);

            bool CanSendPerformRearMeasurementCommand()
            {
                return CanSendNextCommandToRemSystem &&
                       this.officeSystemManager?.IsConnectedToRemModule == true &&
                       Indicators.WasModuleShowed == ControlState.Success ||
                       Indicators.WasModuleShowed == ControlState.Warning;
            }
            var rearMeasurementSettingsCommand = new RelayCommand(() =>
            {
                CreateImcSettings(CommandType.RearMeasurement);
                ShowImcSettings();
            }, CanSendPerformRearMeasurementCommand);
            var performRearMeasurement = new ImcTestCommand(() =>
            {
                CanSendNextCommandToRemSystem = false;
                Indicators.WasRearMeasurementPerformed = ControlState.Error;

                var result = this.imcManager.SetRearMeasurementConditions();
                Indicators.WasRearMeasurementCommandSent = ImcCommandResultToControlState(result);
                //if (result == ImcCommandResult.Error)
                    //return ControlState.Error;

                result = this.imcManager.PerformRearMeasurement();
                Indicators.WasRearMeasurementCommandSent = ImcCommandResultToControlState(result);

                return Indicators.WasRearMeasurementCommandSent;
            }, CanSendPerformRearMeasurementCommand)
            {
                Id = CommandId.RearMeasurement,
                Label = "Rear Measurement",
                OpenSettingsCommand = rearMeasurementSettingsCommand
            };
            ImcCommands.Add(performRearMeasurement);
        }

        private void CreateImcSettings(CommandType commandType)
        {
            SelectionSettings.Clear();
            foreach (var settingKey in this.imcSettingsManager.GetSettingKeys(commandType))
            {
                var setting = new SelectionSetting(value => this.imcSettingsManager.SetSetting(settingKey, value))
                {
                    Label = this.imcSettingsManager.GetSettingLabel(settingKey),
                    Values = this.imcSettingsManager.GetSettingOptions(settingKey),
                    SelectedValue = this.imcSettingsManager.GetSelectedSettingOption(settingKey)
                };
                SelectionSettings.Add(setting);
            }
        }

        private static ControlState ImcCommandResultToControlState(ImcCommandResult result)
        {
            switch (result)
            {
                case ImcCommandResult.Error:
                    return ControlState.Error;

                case ImcCommandResult.Success:
                    return ControlState.Success;

                case ImcCommandResult.Warning:
                    return ControlState.Warning;

                default:
                    return ControlState.NotSet;
            }
        }

        private void CreateMenuItemsFromModules()
        {
            ModulesMenuItems.Clear();
            if (!HearingSoftwareModules.Any())
            {
                ModulesMenuItems.Add(new MenuItem
                {
                    Header = "Modules unavailable",
                    IsEnabled = false
                });

                return;
            }

            ModulesMenuItems.Add(new MenuItem { Header = "Close current module", Command = ViewCommands.CloseRemModule });
            ModulesMenuItems.Add(new Separator());

            // CreateMenuItem function
            MenuItem CreateMenuItem(HearingSoftwareModule module)
            {
                MenuItem menuItem = new MenuItem
                {
                    Header = module.ModulePrintName,
                    Command = ViewCommands.LaunchRemModule,
                    IsEnabled = module.Protocols.Any(a => a.Number == 2)
                };
                menuItem.Click += (sender, args) => this.activeRemModule = module;

                return menuItem;
            }

            HearingSoftwareModules.Select(CreateMenuItem).ForEach(menuItem => ModulesMenuItems.Add(menuItem));
        }

        private void SubscribeToOfficeSystemEvents()
        {
            if (this.officeSystemManager == null)
            {
                return;
            }

            // Office system connection
            this.officeSystemManager.OfficeSystemConnectedEvent += OnOfficeSystemConnected;
            this.officeSystemManager.OfficeSystemDisconnectedEvent += OnOfficeSystemDisonnected;
            // REM module connection
            this.officeSystemManager.RemModuleLaunchedEvent += OnRemModuleLaunched;
            this.officeSystemManager.RemModuleClosedEvent += OnRemModuleClosed;
        }

        private void UnsubscribeFromOfficeSystemEvents()
        {
            if (this.officeSystemManager == null)
            {
                return;
            }

            // Office system connection
            this.officeSystemManager.OfficeSystemConnectedEvent -= OnOfficeSystemConnected;
            this.officeSystemManager.OfficeSystemDisconnectedEvent -= OnOfficeSystemDisonnected;
            // REM module connection
            this.officeSystemManager.RemModuleLaunchedEvent -= OnRemModuleLaunched;
            this.officeSystemManager.RemModuleClosedEvent -= OnRemModuleClosed;
        }

        private void SubscribeToImcManagerEvents()
        {
            this.imcManager.HeartBeatEvent += OnHeartBeatOccured;
            this.imcManager.SystemPreparedEvent += OnSystemPrepared;
            this.imcManager.SweepEndedEvent += OnSweepEnded;
            this.imcManager.MeasurementEndedEvent += OnMeasurementEnded;
            this.imcManager.ProbeTubeCalibrationEndedEvent += OnProbeTubeCalibrationEnded;
        }

        private void UnsubscribeFromImcManagerEvents()
        {
            this.imcManager.HeartBeatEvent -= OnHeartBeatOccured;
        }

        private void RefreshHint()
        {
            if (this.officeSystemManager == null)
            {
                Hint = HintHelper.NoRunModeSelectedHint;
                return;
            }

            if (!this.officeSystemManager.IsConnectedToRemModule)
            {
                Hint = HintHelper.ConnectToRemModuleHint;
                return;
            }

            Hint = HintHelper.EmptyHint;
        }

        private void RefreshImcCommands()
        {
            ImcCommands.ForEach(c => c.Refresh());
        }

        private void UpdatePercentileIndicators(IEnumerable<MeasurementPoint> points, MeasurementSide? side)
        {
            if (points == null)
                return;

            var measurementPoints = points.ToList();
            switch (side)
            {
                case MeasurementSide.Left:
                    Indicators.WasLeftPercentile1Received = measurementPoints.Any(a => a.Percentile1 != 0) ? ControlState.Success : ControlState.Error;
                    Indicators.WasLeftPercentile2Received = measurementPoints.Any(a => a.Percentile2 != 0) ? ControlState.Success : ControlState.Error;
                    break;

                case MeasurementSide.Right:
                    Indicators.WasRightPercentile1Received = measurementPoints.Any(a => a.Percentile1 != 0) ? ControlState.Success : ControlState.Error;
                    Indicators.WasRightPercentile2Received = measurementPoints.Any(a => a.Percentile2 != 0) ? ControlState.Success : ControlState.Error;
                    break;
            }
        }

        private void UpdateSiiIndicators(SweepEndedData data)
        {
            Indicators.WasLeftAidedSiiReceived = data.AidedSii?.Left >= 0 ? ControlState.Success : ControlState.Error;
            Indicators.WasLeftUnaidedSiiReceived = data.UnaidedSii?.Left >= 0 ? ControlState.Success : ControlState.Error;
            Indicators.WasRightAidedSiiReceived = data.AidedSii?.Right >= 0 ? ControlState.Success : ControlState.Error;
            Indicators.WasRightUnaidedSiiReceived = data.UnaidedSii?.Right >= 0 ? ControlState.Success : ControlState.Error;
        }

        private void ResetRemIndicators()
        {
            Indicators.DidHeartBeatOccur = ControlState.Error;
            Indicators.WasModuleShowed = ControlState.Error;
            Indicators.WasLeftPercentile1Received = ControlState.Error;
            Indicators.WasLeftPercentile2Received = ControlState.Error;
            Indicators.WasRightPercentile1Received = ControlState.Error;
            Indicators.WasRightPercentile2Received = ControlState.Error;
            Indicators.WasProbeTubeCalibrationCommandSent = ControlState.Error;
            Indicators.WasProbeTubeCalibrationPerformed = ControlState.Error;
            Indicators.WasProtololNoSet = ControlState.Error;
            Indicators.WasRearMeasurementCommandSent = ControlState.Error;
            Indicators.WasRearMeasurementPerformed = ControlState.Error;
            Indicators.WasPrepareSystemCommandSent = ControlState.Error;
            Indicators.WasLeftAidedSiiReceived = ControlState.Error;
            Indicators.WasLeftUnaidedSiiReceived = ControlState.Error;
            Indicators.WasRightAidedSiiReceived = ControlState.Error;
            Indicators.WasRightUnaidedSiiReceived = ControlState.Error;
            Indicators.WasSystemPrepared = ControlState.Error;
        }

        private void ShowImcSettings() => AreCommandSettingsVisible = true;

        private void HideImcSettings() => AreCommandSettingsVisible = false;

        #endregion



        #region #### OfficeSystemManager 

        private IOfficeSystemManager officeSystemManager;

        private OfficeSystemData officeSystemData;
        public OfficeSystemData OfficeSystemData
        {
            get => this.officeSystemData;
            set
            {
                this.officeSystemData = value;
                RaisePropertyChanged(nameof(MainWindowViewModel.OfficeSystemData));
            }
        }

        private readonly ImcManager imcManager = ImcManager.GetImcManager();

        private readonly ImcSettingsManager imcSettingsManager = ImcSettingsManager.GetImcSettingsManager();

        public ObservableCollection<HearingSoftwareModule> HearingSoftwareModules { get; set; } = new ObservableCollection<HearingSoftwareModule>();

        private HearingSoftwareModule activeRemModule;

        private DateTime heartBeatLastUpdate = DateTime.Now;

        private RunMode runMode = RunMode.None;
        public RunMode RunMode
        {
            get => this.runMode;
            set
            {
                if (value == RunMode)
                    return;

                this.officeSystemManager?.Disconnect();
                UnsubscribeFromOfficeSystemEvents();
                this.imcManager.UnsubscribeFromOfficeSystemEvents(this.officeSystemManager);

                this.runMode = value;
                switch (this.runMode)
                {
                    case RunMode.Standalone:
                        this.officeSystemManager = StandaloneOfficeSystemManager.GetOfficeSystemManager();
                        break;

                    case RunMode.Noah:
                        this.officeSystemManager = NoahOfficeSystemManager.GetOfficeSystemManager();
                        break;

                    case RunMode.None:
                        this.officeSystemManager = null;
                        break;

                    default:
                        throw new ArgumentOutOfRangeException(nameof(value), value, null);
                }

                SubscribeToOfficeSystemEvents();
                this.imcManager.SubscribeToOfficeSystemEvents(this.officeSystemManager);
                HearingSoftwareModules.Clear();

                if (this.officeSystemManager != null && this.officeSystemManager.Connect())
                {
                    this.officeSystemManager.GetHearingSoftwareModules().ForEach(a => HearingSoftwareModules.Add(a));
                }
                else
                {
                    this.officeSystemManager = null;
                }

                CreateMenuItemsFromModules();
                RaisePropertyChanged(nameof(MainWindowViewModel.RunMode));
                RefreshHint();
            }
        }

        private readonly OfficeSystemData noOfficeSystemData = new OfficeSystemData
        {
            Label = "None"
        };

        #endregion



        #region #### Interval Tasks

        private void StartIntervalTasks()
        {
            Timer heartBeatTimer = new Timer();
            heartBeatTimer.Elapsed += (e, args) =>
            {
                if (Indicators.DidHeartBeatOccur != ControlState.Error && (DateTime.Now - this.heartBeatLastUpdate).Seconds > 5)
                {
                    Indicators.DidHeartBeatOccur = ControlState.Error;
                }
            };

            heartBeatTimer.Start();
        }

        #endregion



        #region #### Event Handlers

        private void OnOfficeSystemConnected(object sender, OfficeSystemConnectedEventArgs e)
        {
            OfficeSystemData = e.Data;
            Indicators.IsRunModeSelected = ControlState.Success;
            RefreshHint();
            this.loggingManager.Log(new UserMessage
            {
                MessageType = MessageType.Internal,
                ControlState = ControlState.Success,
                Header = "Office system connected",
                Message = e.Data.Label
            });
        }

        private void OnOfficeSystemDisonnected(object sender, OfficeSystemDisconnectedEventArgs e)
        {
            OfficeSystemData = this.noOfficeSystemData;
            Indicators.IsRunModeSelected = ControlState.Error;
            RefreshHint();
            this.loggingManager.Log(new UserMessage
            {
                MessageType = MessageType.Internal,
                ControlState = ControlState.Success,
                Header = "Office system disconnected",
                Message = e.Data.Label
            });
        }

        private void OnRemModuleLaunched(object sender, RemModuleLaunchedEventArgs e)
        {
            Indicators.IsModuleConnected = ControlState.Success;
            RefreshHint();
            this.loggingManager.Log(new UserMessage
            {
                MessageType = MessageType.Internal,
                ControlState = ControlState.Success,
                Header = "REM module launched",
                Message = e.Data.ModulePrintName
            });
        }

        private void OnRemModuleClosed(object sender, RemModuleClosedEventArgs e)
        {
            Indicators.IsModuleConnected = ControlState.Error;
            Indicators.DidHeartBeatOccur = ControlState.Error;
            this.heartBeatLastUpdate = DateTime.MinValue;
            RefreshHint();
            this.loggingManager.Log(new UserMessage
            {
                MessageType = MessageType.Internal,
                ControlState = ControlState.Success,
                Header = "REM module connection closed",
                Message = e.Data.ModulePrintName
            });

            ResetRemIndicators();
            ImcCommands.Clear();
            InitializeImcCommands();
        }

        private void OnHeartBeatOccured(object sender, HeartBeatOccuredEventArgs e)
        {
            Indicators.DidHeartBeatOccur = ControlState.Success;
            this.heartBeatLastUpdate = e.Data.Time;
            /*
            LoggingManager.Log(new UserMessage
            {
                MessageType = MessageType.Received,
                ControlState = ControlState.Success,
                Header = "HeartBeat received",
                Message = e.Data.Time.ToLongTimeString()
            });
            */
        }

        private void OnSystemPrepared(object sender, SystemPreparedEventArgs e)
        {
            CanSendNextCommandToRemSystem = true;
            Indicators.WasSystemPrepared = ControlState.Success;
            this.loggingManager.Log(new UserMessage
            {
                MessageType = MessageType.Received,
                ControlState = ControlState.Success,
                Header = "PrepareSystem",
                Message = "PrepareSystem ended with success"
            });
        }

        private void OnSweepEnded(object sender, SweepEndedEventArgs e)
        {
            UpdateSiiIndicators(e.Data);
            UpdatePercentileIndicators(e.Data?.Data, e.Data?.Side);
            if (this.lastSweepEndedUserMessageGuid == null)
            {
                this.lastSweepEndedUserMessageGuid = this.loggingManager.Log(new UserMessage
                {
                    MessageType = MessageType.Received,
                    ControlState = ControlState.Success,
                    Header = "Measurement data",
                    Message = "Measurement data received"
                });
            }
            else
            {
                StringBuilder label = new StringBuilder();
                label.Append("Side").Append(Environment.NewLine).Append("SIIs").Append(Environment.NewLine)
                    .Append("Frequency").Append(Environment.NewLine).Append("Output").Append(Environment.NewLine)
                    .Append("Percentile1").Append(Environment.NewLine).Append("Percentile2");

                StringBuilder description = new StringBuilder()
                    .Append(e.Data?.Side)
                    .Append(Environment.NewLine).Append(
                        $"Unaided - {e.Data?.AidedSii.GetValue(e.Data.Side)}, Aided - {e.Data?.UnaidedSii.GetValue(e.Data.Side)}")
                    .Append(Environment.NewLine).Append(e.Data?.Data
                        .Select(a => (a.Frequency.ToString(CultureInfo.InvariantCulture) + "kHz").PadLeft(9))
                        .Aggregate((a, b) => a + b))
                    .Append(Environment.NewLine).Append(e.Data?.Data
                        .Select(a => a.Output.ToString("000.00", CultureInfo.InvariantCulture).PadLeft(9))
                        .Aggregate((a, b) => a + b))
                    .Append(Environment.NewLine).Append(e.Data?.Data
                        .Select(a => a.Percentile1.ToString("000.00", CultureInfo.InvariantCulture).PadLeft(9))
                        .Aggregate((a, b) => a + b))
                    .Append(Environment.NewLine).Append(e.Data?.Data
                        .Select(a => a.Percentile2.ToString("000.00", CultureInfo.InvariantCulture).PadLeft(9))
                        .Aggregate((a, b) => a + b));

                this.loggingManager.AddUserMessageDetails(this.lastSweepEndedUserMessageGuid, new Tuple<string, string>(label.ToString(), description.ToString()));
            }
        }

        private void OnMeasurementEnded(object sender, SweepEndedEventArgs e)
        {
            CanSendNextCommandToRemSystem = true;
            this.lastSweepEndedUserMessageGuid = null;
            UpdateSiiIndicators(e.Data);
            UpdatePercentileIndicators(e.Data?.Data, e.Data?.Side);

            var measurementType = this.imcManager.GetLastMeasurementType();
            UserMessage userMessage = null;
            switch (measurementType)
            {
                case MeasurementType.Rear:
                    Indicators.WasRearMeasurementPerformed = ControlState.Success;
                    switch (Indicators.WasRearMeasurementPerformed)
                    {
                        case ControlState.Success:
                            userMessage = new UserMessage
                            {
                                MessageType = MessageType.Received,
                                ControlState = ControlState.Success,
                                Header = "Rear Measurement ended",
                                Message = "Rear Measurement performed with success"
                            };
                            break;
                        case ControlState.Error:
                            userMessage = new UserMessage
                            {
                                MessageType = MessageType.Received,
                                ControlState = ControlState.Error,
                                Header = "Rear Measurement ended",
                                Message = "Rear Measurement performed with warning"
                            };
                            break;
                        case ControlState.Warning:
                            userMessage = new UserMessage
                            {
                                MessageType = MessageType.Received,
                                ControlState = ControlState.Warning,
                                Header = "Rear Measurement ended",
                                Message = "Rear Measurement performed with error"
                            };
                            break;
                    }
                    break;
                default:
                    return;
            }

            if (userMessage != null)
            {
                string label = "Side" + Environment.NewLine + "SIIs";
                string description = e.Data?.Side + Environment.NewLine + $"Unaided - {e.Data?.AidedSii.GetValue(e.Data.Side)}, Aided - {e.Data?.UnaidedSii.GetValue(e.Data.Side)}";
                Tuple<string, string> detail = new Tuple<string, string>(label, description);
                userMessage.Details.Add(detail);
                userMessage.Details.Add(new Tuple<string, string>("Received data", e.Data?.Json));

                this.loggingManager.Log(userMessage);
            }
        }

        private void OnProbeTubeCalibrationEnded(object sender, ProbeTubeCalibrationEndedEventArgs e)
        {
            CanSendNextCommandToRemSystem = true;
            this.lastSweepEndedUserMessageGuid = null;
            Indicators.WasProbeTubeCalibrationPerformed = ControlState.Success;

            UserMessage userMessage = new UserMessage
            {
                MessageType = MessageType.Received,
                ControlState = ControlState.Success,
                Header = "ProbeTubeCalibration",
                Message = "ProbeTubeCalibration performed with success"
            };
            userMessage.Details.Add(new Tuple<string, string>("Received data", e.Data?.Json));

            this.loggingManager.Log(userMessage);
        }

        #endregion


        #region MessageDetails functionality

        private bool areMessageDetailsVisible;
        public bool AreMessageDetailsVisible
        {
            get => this.areMessageDetailsVisible;
            private set
            {
                this.areMessageDetailsVisible = value;
                RaisePropertyChanged(nameof(MainWindowViewModel.areMessageDetailsVisible));
            }
        }

        private void HideDetails() => AreMessageDetailsVisible = false;

        private void WriteWriteMessageToLogFile()
        {
            this.loggingManager.LogMessageToFile(this.activeUserMessage?.Guid);
        }

        private UserMessage activeUserMessage;

        public UserMessage ActiveUserMessage
        {
            get => this.activeUserMessage;
            private set
            {
                this.activeUserMessage = value;
                RaisePropertyChanged(nameof(MainWindowViewModel.ActiveUserMessage));
            }
        }

        public void ShowMessageDetails(string messageGuid)
        {
            if (UserMessages.All(a => a.Guid != messageGuid))
                return;

            AreMessageDetailsVisible = true;
            ActiveUserMessage = UserMessages.Single(a => a.Guid == messageGuid);
        }

        #endregion
    }
}
