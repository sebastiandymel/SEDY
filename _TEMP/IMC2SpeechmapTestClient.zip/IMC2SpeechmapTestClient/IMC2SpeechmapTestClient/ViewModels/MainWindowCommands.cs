﻿using System.Windows.Input;

namespace IMC2SpeechmapTestClient.ViewModels
{
    public class MainWindowCommands
    {
        public ICommand Quit { get; set; }
        public ICommand SetRunModeToStandalone { get; set; }
        public ICommand SetRunModeToNoah { get; set; }
        public ICommand RegisterMyselfInCurrentMode { get; set; }
        public ICommand SetRunModeToNone { get; set; }

        public ICommand LaunchRemModule { get; set; }

        public ICommand CloseRemModule { get; set; }

        public ICommand ClearLogs { get; set; }

        public ICommand CloseSettings { get; set; }

        public ICommand CloseDetails { get; set; }

        public ICommand WriteMessageToLogFile { get; set; }

        public ICommand InvertSaveAllMessagesToAFile { get; set; }
    }
}
