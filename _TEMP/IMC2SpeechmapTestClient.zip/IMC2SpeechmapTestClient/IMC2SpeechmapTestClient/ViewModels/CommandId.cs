﻿namespace IMC2SpeechmapTestClient.ViewModels
{
    public enum CommandId
    {
        SetProtocolNo,
        PrepareSystem,
        ShowModule,
        ProbeTubeCalibration,
        RearMeasurement,
        ReugMeasurement,
    }
}
