﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using IMC2SpeechmapTestClient.Libraries.View;
using System;
using System.Windows.Input;

namespace IMC2SpeechmapTestClient.ViewModels
{
    public class ImcTestCommand : ViewModelBase, ICommand
    {
        private readonly RelayCommand internalCommand;
        private ControlState result;

        public ImcTestCommand(Func<ControlState> execute, Func<bool> canExecute)
        {
            Action proxy = () =>
            {
                Result = execute();
            };
            this.internalCommand = new RelayCommand(proxy, canExecute);

            this.internalCommand.CanExecuteChanged += (s, e) => ToUi(() => CanExecuteChanged(this, EventArgs.Empty));
            CommandManager.RequerySuggested += (s, e) => { ToUi(() => CanExecuteChanged(this, EventArgs.Empty)); };
        }

        public string Label { get; set; }

        public ControlState Result
        {
            get { return this.result; }
            set
            {
                this.result = value;
                RaisePropertyChanged();
            }
        }

        public CommandId Id { get; set; }

        public ICommand OpenSettingsCommand { get; set; }

        #region ICommand members


        public event EventHandler CanExecuteChanged = delegate { };

        public bool CanExecute(object parameter)
        {
            return this.internalCommand.CanExecute(parameter);
        }

        public void Execute(object parameter)
        {
            this.internalCommand.Execute(parameter);
        }

        #endregion ICommand members

        public void Refresh()
        {
            this.internalCommand.RaiseCanExecuteChanged();
        }

        private static void ToUi(Action action)
        {
            System.Windows.Application.Current.Dispatcher.Invoke(action);
        }
    }
}
