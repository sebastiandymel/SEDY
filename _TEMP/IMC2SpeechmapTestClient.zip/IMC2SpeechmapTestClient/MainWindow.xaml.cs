﻿using System.ComponentModel;
using System.Windows;
using System.Windows.Input;
using IMC2SpeechmapTestClient.Libraries.OfficeSystem.OfficeSystemManagers;
using IMC2SpeechmapTestClient.ViewModels;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace IMC2SpeechmapTestClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            //convert Enums to Strings (instead of Integer) globally
            JsonConvert.DefaultSettings = () =>
            {
                var settings = new JsonSerializerSettings();
                settings.Converters.Add(new StringEnumConverter { CamelCaseText = false });
                return settings;
            };

            InitializeComponent();
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                DragMove();
        }

        private void MainWindow_OnClosing(object sender, CancelEventArgs e)
        {
            if (!(DataContext is MainWindowViewModel mainWindowViewModel))
                return;

            switch (mainWindowViewModel.OfficeSystemData?.OfficeSystemName)
            {
                case nameof(StandaloneOfficeSystemManager):
                    StandaloneOfficeSystemManager.GetOfficeSystemManager().Disconnect();
                    return;

                case nameof(NoahOfficeSystemManager):
                    NoahOfficeSystemManager.GetOfficeSystemManager().Disconnect();
                    return;
            }
        }
    }
}
