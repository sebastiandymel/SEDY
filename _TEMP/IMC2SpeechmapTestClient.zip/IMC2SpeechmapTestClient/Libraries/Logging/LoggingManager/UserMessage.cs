﻿using System;
using System.Collections.ObjectModel;
using GalaSoft.MvvmLight;
using IMC2SpeechmapTestClient.Libraries.View;

namespace IMC2SpeechmapTestClient.Libraries.Logging
{
    public class UserMessage : ViewModelBase
    {
        public string Guid { get; set; }

        public DateTime Time { get; set; } = DateTime.Now;

        public string Header { get; set; }

        public string Message { get; set; }

        private int counter;
        public int Counter
        {
            get => this.counter;
            set
            {
                this.counter = value;
                RaisePropertyChanged(nameof(UserMessage.Counter));
            }
        }

        private bool isSaved;
        public bool IsSaved
        {
            get => this.isSaved;
            set
            {
                this.isSaved = value;
                RaisePropertyChanged(nameof(UserMessage.IsSaved));
            }
        }

        public ControlState ControlState { get; set; }

        public MessageType MessageType { get; set; }

        public ObservableCollection<Tuple<string, string>> Details { get; set; } = new ObservableCollection<Tuple<string, string>>();
    }
}
