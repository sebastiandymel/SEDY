﻿namespace IMC2SpeechmapTestClient.Libraries.View
{
    public class Hint
    {
        public FontAwesome.WPF.FontAwesome FontAwesome { get; set; }

        public string Message { get; set; }

        public HintType HintType { get; set; }
    }
}
