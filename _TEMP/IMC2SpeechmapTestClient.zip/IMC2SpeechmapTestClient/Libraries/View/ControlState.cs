﻿namespace IMC2SpeechmapTestClient.Libraries.View
{
    public enum ControlState
    {
        Error,
        Warning,
        Success,
        NotSet
    }
}
