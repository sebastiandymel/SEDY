﻿namespace IMC2SpeechmapTestClient.Libraries.IMC.DataTypes
{
    public enum SettingKey
    {
        // General
        ProtocolNumber,
        Side,
        ShowMode,
        MeasurementIdentification,
        SignalType,
        // Rear specific
        RearSignalLevel,
        RearAveragingTime
    }
}
