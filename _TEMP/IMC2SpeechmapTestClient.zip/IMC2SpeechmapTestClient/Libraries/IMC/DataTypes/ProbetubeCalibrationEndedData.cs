﻿namespace IMC2SpeechmapTestClient.Libraries.IMC.DataTypes
{
    public class ProbetubeCalibrationEndedData
    {
        public string Json { get; set; }
    }
}
