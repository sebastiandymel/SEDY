﻿namespace IMC2SpeechmapTestClient.Libraries.IMC.DataTypes
{
    public enum MeasurementSide
    {
        Left,
        Right,
        Both
    }
}
