﻿using System.Threading;
using System.Threading.Tasks;

namespace IMC2SpeechmapTestClient.Libraries.OfficeSystem.OfficeSystemManagers
{
    internal static class TaskExtensions
    {
        internal static async Task<bool> AwaitWithTimeout(this Task job, CancellationToken token, int timeout)
        {
            if (await Task.WhenAny(job, Task.Delay(timeout, token)) == job)
            {
                await job;
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
