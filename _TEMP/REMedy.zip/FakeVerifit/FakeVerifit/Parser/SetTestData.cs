namespace FakeVerifit
{
    class SetTestData
    {
        public string Mode { get; set; }
        public Side Side { get; set; }
        public string SlotNumber { get; set; }
        public string StimulusName { get; set; }
        public string Level { get; set; }
    }
}