﻿namespace FakeVerifit
{
    class Quotes
    {
        public static string[] Trump => new[] { "Despite the constant negative press covfefe", "I know nothing about Russia. I know — I know about Russia", "I have great respect for women. Nobody has more respect for women than I do." };
    }
}
