﻿namespace REMedy.Updater
{
    public enum UpdateResult
    {
        WrongFile,
        UserStopped,
        Success
    }
}
