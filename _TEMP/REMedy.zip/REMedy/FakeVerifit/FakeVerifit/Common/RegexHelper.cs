﻿namespace FakeVerifit
{
    internal class RegexHelper
    {
        public static string WordEx => @"([\w|-]+)";
    }
}