namespace FakeVerifit
{
    public static class UIBridgeConstants
    {
        public const string Verifit1 = "vf1";
        public const string Verifit2 = "vf2";
        public const string ApiVersion3 = "3.0.0";
        public const string ApiVersion2 = "2.0.0";
        public const string FakeVerifit = "fv";
    }
}