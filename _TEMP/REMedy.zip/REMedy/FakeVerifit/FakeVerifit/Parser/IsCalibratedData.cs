﻿namespace FakeVerifit
{
    class IsCalibratedData
    {
        public string Mode { get; set; }
        public Side Side { get; set; }
    }
}