﻿using System;

namespace FakeIMC.Core
{
    public class ImcEventArgs : EventArgs
    {
        public string Message { get; set; }
    }
}