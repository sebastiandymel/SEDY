﻿using System;

namespace FakeIMC.Core
{
    public class ImcExitArgs : EventArgs
    {
        public Action ExitAction { get; set; }
    }
}