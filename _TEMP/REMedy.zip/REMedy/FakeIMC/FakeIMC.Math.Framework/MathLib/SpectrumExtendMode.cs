﻿namespace FakeIMC.Math
{
    public enum SpectrumExtendMode
    {
        None,
        Extrapolate,
        Flat
    }
}
