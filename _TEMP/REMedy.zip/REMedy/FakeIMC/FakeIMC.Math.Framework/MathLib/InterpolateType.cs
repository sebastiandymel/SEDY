﻿namespace FakeIMC.Math
{
    public enum InterpolateType
    {
        Logarithmic,
        Linear
    }
}
