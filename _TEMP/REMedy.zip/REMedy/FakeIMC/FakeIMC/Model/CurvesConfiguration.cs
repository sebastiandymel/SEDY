﻿namespace FakeIMC
{
    public class CurvesConfiguration
    {
        public bool AddRandomValues { get; set; }
        public bool AddReugToReag { get; set; }
        public double SpeechLowOffset { get; set; }
        public double SpeechHighOffset { get; set; }
        public double SiiAided { get; set; }
        public double SiiUnaided { get; set; }
    }
}