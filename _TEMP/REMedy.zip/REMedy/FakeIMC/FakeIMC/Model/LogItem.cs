﻿namespace FakeIMC
{
    public class LogItem
    {
        public string Text { get; set; }
        public Severity Severity { get; set; }


    }
}