﻿namespace FakeIMC
{
    public enum CurveType
    {
        Output,
        Reug,
        Percentiles30,
        Percentiles99,
        Ltass
    }
}