﻿namespace FakeIMC
{
    public enum Severity
    {
        Normal,
        Warning,
        Error
    }
}