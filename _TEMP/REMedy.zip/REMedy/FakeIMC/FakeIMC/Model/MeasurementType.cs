﻿namespace FakeIMC
{
    public enum MeasurementType
    {
        Unaided,
        Aided
    }
}