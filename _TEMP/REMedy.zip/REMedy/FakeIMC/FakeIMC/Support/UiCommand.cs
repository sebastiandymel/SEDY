﻿using Reactive.Bindings;

namespace FakeIMC.UI
{
    internal class UiCommand : ReactiveCommand
    {
        public string Label { get; set; }
    }
}
