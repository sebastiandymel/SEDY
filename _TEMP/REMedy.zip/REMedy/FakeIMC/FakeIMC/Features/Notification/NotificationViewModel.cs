﻿namespace FakeIMC.UI
{
    public class NotificationViewModel
    {
        public string Title { get; set; }
        public string Message { get; set; }
        public string Message2 { get; set; }
    }
}