﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interactivity;

namespace FakeIMC.UI
{
    public class CellBehavior : Behavior<FrameworkElement>
    {
        /// <summary>
        /// Target elements to attach hover effect
        /// </summary>
        public ItemsControl Target
        {
            get => (ItemsControl)GetValue(CellBehavior.TargetProperty);
            set => SetValue(CellBehavior.TargetProperty, value);
        }
        public static readonly DependencyProperty TargetProperty = DependencyProperty.Register("Target", typeof(ItemsControl), typeof(CellBehavior), new PropertyMetadata(null));
        
        public FrameworkElement ParentContainer
        {
            get
            {
                return (FrameworkElement)GetValue(CellBehavior.ParentContainerProperty);
            }
            set
            {
                SetValue(CellBehavior.ParentContainerProperty, value);
            }
        }
        public static readonly DependencyProperty ParentContainerProperty = DependencyProperty.Register("ParentContainer", typeof(FrameworkElement), typeof(CellBehavior), new PropertyMetadata(null));
        
        protected override void OnAttached()
        {
            base.OnAttached();
            AssociatedObject.Loaded += OnLoaded;
            AssociatedObject.MouseEnter += OnEnter;
            AssociatedObject.MouseLeave += OnLeave;
            AssociatedObject.MouseLeftButtonDown += OnLeftDown;            
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            if (ParentContainer == null)
            {
                return;
            }

            ParentContainer.MouseWheel += OnParentMouseWheel;
            Target.IsEnabledChanged += OnTargetIsEnabledChanged;
        }

        private void OnTargetIsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            foreach (var item in Target.Items.OfType<FreqValCell>())
            {
                item.IsSelected = false;
                item.IsEditMode = false;
            }
            ForEachContainer(c => CellExtensions.SetIsHovered(c, false));
        }

        private void OnParentMouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (!Target.IsEnabled)
            {
                // Do not handled mouse wheel if element is disabled
                return;
            }
            foreach (var item in Target.Items.OfType<FreqValCell>().Where(c => c.IsSelected))
            {
                if (e.Delta > 0)
                {
                    item.Increase();
                }
                else
                {
                    item.Decrease();
                }
            }
        }

        protected override void OnDetaching()
        {
            base.OnDetaching();
            AssociatedObject.MouseEnter -= OnEnter;
            AssociatedObject.MouseLeave -= OnLeave;
            AssociatedObject.MouseLeftButtonDown -= OnLeftDown;
        }

        private void OnLeftDown(object sender, MouseButtonEventArgs e)
        {
            var anySelected = Target.Items.OfType<FreqValCell>().Any(c => c.IsSelected);
            foreach (var item in Target.Items.OfType<FreqValCell>())
            {
                item.IsSelected = !anySelected;
            }
        }

        private void OnLeave(object sender, MouseEventArgs e)
        {
            ForEachContainer(c => CellExtensions.SetIsHovered(c, false));
        }

        private void OnEnter(object sender, MouseEventArgs e)
        {
            ForEachContainer(c => CellExtensions.SetIsHovered(c, true));
        }

        private void ForEachContainer(Action<DependencyObject> invoke)
        {
            if (Target == null)
            {
                return;
            }
            foreach (var item in Target.Items)
            {
                var container = Target.ItemContainerGenerator.ContainerFromItem(item);
                if (container != null)
                {
                    invoke(container);
                }
            }
        }
    }
}