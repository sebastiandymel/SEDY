﻿namespace FakeIMC.UI
{
    public class DesignDataGridViewModel : GridViewModel
    {
        public DesignDataGridViewModel(): base(new GridModelStub())
        {
            
        }
    }
}