﻿namespace Remedy.Core
{
    public interface IFreqVal
    {
        int Frequency { get; }

        string Value { get; }
    }
}
