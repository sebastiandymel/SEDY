﻿namespace Remedy.CommonUI
{
    public enum SizeChange
    {
        Started,
        Finished
    }
}