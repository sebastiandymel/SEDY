﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;

namespace Remedy.CommonUI
{
    public static class SingleAppInstance
    {
        private static Mutex singleAppMutex;
        public static bool Register(string name)
        {
                        string mutexId = string.Format("Global\\REMedy-{0}",name);

                var mx = new Mutex(true, mutexId, out var created);
                if (created)
                {
                singleAppMutex = mx;
                    return true;
                }
                return false;
            }
        

        public static void Release(string name)
        {
            try
            {
                singleAppMutex?.ReleaseMutex();
            }catch{ }
        }
    }
}