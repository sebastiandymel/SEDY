﻿namespace REMedy.Updater
{
    public interface IUpdaterConfigurationReader
    {
        UpdaterConfiguration Read();
    }
}
