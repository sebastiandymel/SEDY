﻿using System.Windows;
using System.Windows.Controls;
using Unity;
using REMedy.Updater;
using Remedy.CommonUI;

namespace FakeIMC.UI
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static UnityContainer Container { get; set; }
        private UnhandledExceptionHandler exceptionHandler;

        protected override void OnStartup(StartupEventArgs e)
        {
            if (!SingleAppInstance.TryRegister("FakeIMC"))
            {
                MessageBox.Show("Only one instance of FakeIMC can run at the same time", "Warning");
                Application.Current?.Shutdown(1);
                return;
            }

            base.OnStartup(e);

            App.Container = new UnityContainer();
            App.Container.AddNewExtension<Unity.Interception.ContainerIntegration.Interception>();
            App.Container.AddNewExtension<CompositionModule>();

            ToolTipService.ShowDurationProperty
                .OverrideMetadata(typeof(FrameworkElement),
                    new FrameworkPropertyMetadata(60_000));

            var mw = App.Container.Resolve<MainWindow>();
            mw.Show();

            UpdaterServiceFacade.Run(new UpdaterNorification());

            this.exceptionHandler = new UnhandledExceptionHandler();
            this.exceptionHandler.Initialize();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            SingleAppInstance.Release("FakeIMC");
            base.OnExit(e);
        }
    }
}
