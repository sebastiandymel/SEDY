﻿namespace FakeIMC
{
    public enum CurveLevel
    {
        Low,
        Medium,
        High,
    }
}