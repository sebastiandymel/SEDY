﻿using System;

namespace FakeIMC
{
    [AttributeUsage(AttributeTargets.Method)]
    public class DispatchToUiAttribute : Attribute
    {

    }
}