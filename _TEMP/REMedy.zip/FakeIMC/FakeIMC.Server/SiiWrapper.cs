﻿using System;
using Himsa.IMC2.DataDefinitions;
using Newtonsoft.Json;

namespace FakeIMC.Server
{
    internal class SiiWrapper
    {
        private readonly double aided;
        private readonly double unaided;

        internal SiiWrapper(double aided, double unaided)
        {
            this.aided = aided;
            this.unaided = unaided;
        }

        internal string AsJson(TSide side)
        {
            return JsonConvert.SerializeObject(CreateSii(this.aided, this.unaided, side));
        }

        #region SII

        private SiiRoot CreateSii(double aided, double unaided, TSide side)
        {
            var hasLeft = side == TSide.Binaural || side == TSide.Left;
            var hasRight = side == TSide.Binaural || side == TSide.Right;
            return new SiiRoot
            {
                // Speech intelligibility index (SII) is a measure, between 0 and 100,
                // that represents the intelligibility of speech under a variety of adverse
                // listening conditions, such as noise masking, filtering, and reverberation.
                Result = new Result
                {
                    Side = new Side
                    {
                        Left = hasLeft ? new Left
                        {
                            Sii = new Sii
                            {
                                Aided = ToInt(aided),
                                Unaided = ToInt(unaided)
                            }
                        } : null,
                        Right = hasRight ? new Right
                        {
                            Sii = new Sii
                            {
                                Aided = ToInt(aided),
                                Unaided = ToInt(unaided)
                            }
                        } : null
                    }
                }
            };
        }

        /// <summary>
        /// Speech intelligibility index (SII) is a measure, between 0 and 100,
        /// that represents the intelligibility of speech under a variety of adverse
        /// listening conditions, such as noise masking, filtering, and reverberation.
        /// Speech cues interrupted by fewer of these conditions will be more available
        /// to the listener, and will thus have a higher SII value.
        /// </summary>
        private class SiiRoot
        {
            [JsonProperty("jsonrpc", Required = Required.Always)]

            public string Jsonrpc { get; set; } = "2.0";
            [JsonProperty("result", Required = Required.Always)]
            public Result Result { get; set; }
        }
        private class Result
        {
            [JsonProperty("side", Required = Required.Always)]
            public Side Side { get; set; }
        }
        private class Side
        {
            [JsonProperty("left", Required = Required.AllowNull)]
            public Left Left { get; set; }
            [JsonProperty("right", Required = Required.AllowNull)]
            public Right Right { get; set; }
        }
        private class Left
        {
            [JsonProperty("sii", Required = Required.Always)]
            public Sii Sii { get; set; }
        }
        private class Sii
        {
            [JsonProperty("aided", Required = Required.Always)]
            public int Aided { get; set; }
            [JsonProperty("unaided", Required = Required.Always)]
            public int Unaided { get; set; }
        }
        private class Right
        {
            [JsonProperty("sii", Required = Required.Always)]
            public Sii Sii { get; set; }
        }

        #endregion SII

        private static int ToInt(double value)
        {
            return Convert.ToInt32(System.Math.Round(value, MidpointRounding.AwayFromZero));
        }
    }
}
