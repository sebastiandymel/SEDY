﻿namespace FakeIMC.Math
{
    public enum SearchPredicate
    {
        EqualTo,
        NotEqual,
        LesserThan,
        GreaterThan,
        LesserThanOrEqual,
        GreaterThanOrEqual
    }
}
