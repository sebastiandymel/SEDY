﻿namespace FakeVerifit
{
    enum Side
    {
        Left,
        Right
    }
}