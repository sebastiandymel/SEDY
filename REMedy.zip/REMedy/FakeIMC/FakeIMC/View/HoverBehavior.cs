﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interactivity;

namespace FakeIMC.UI
{
    public class HoverBehavior : Behavior<FrameworkElement>
    {
        /// <summary>
        /// Target elements to attach hover effect
        /// </summary>
        public ItemsControl Target
        {
            get => (ItemsControl)GetValue(HoverBehavior.TargetProperty);
            set => SetValue(HoverBehavior.TargetProperty, value);
        }
        public static readonly DependencyProperty TargetProperty = DependencyProperty.Register("Target", typeof(ItemsControl), typeof(HoverBehavior), new PropertyMetadata(null));

        protected override void OnAttached()
        {
            base.OnAttached();
            AssociatedObject.MouseEnter += OnEnter;
            AssociatedObject.MouseLeave += OnLeave;
            AssociatedObject.MouseLeftButtonDown += OnLeftDown;
        }

        protected override void OnDetaching()
        {
            base.OnDetaching();
            AssociatedObject.MouseEnter -= OnEnter;
            AssociatedObject.MouseLeave -= OnLeave;
            AssociatedObject.MouseLeftButtonDown -= OnLeftDown;
        }

        private void OnLeftDown(object sender, MouseButtonEventArgs e)
        {
            foreach (var item in Target.Items.OfType<FreqValCell>())
            {
                item.IsSelected = !item.IsSelected;
            }
        }

        private void OnLeave(object sender, MouseEventArgs e)
        {
            ForEachContainer(c => HoverExtensions.SetIsHovered(c, false));
        }

        private void OnEnter(object sender, MouseEventArgs e)
        {
            ForEachContainer(c => HoverExtensions.SetIsHovered(c, true));
        }

        private void ForEachContainer(Action<DependencyObject> invoke)
        {
            if (Target == null)
            {
                return;
            }
            foreach (var item in Target.Items)
            {
                var container = Target.ItemContainerGenerator.ContainerFromItem(item);
                if (container != null)
                {
                    invoke(container);
                }
            }
        }
    }
}