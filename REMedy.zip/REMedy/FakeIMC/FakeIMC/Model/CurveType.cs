﻿namespace FakeIMC
{
    public enum CurveType
    {
        Low,
        Medium,
        High,
        Reug
    }
}