﻿namespace FakeIMC
{
    public class CurvesConfiguration
    {
        public bool AddRandomValues { get; set; }
        public bool AddReugToReag { get; set; }
    }
}