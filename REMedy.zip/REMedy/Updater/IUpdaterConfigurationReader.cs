﻿namespace Updater
{
    public interface IUpdaterConfigurationReader
    {
        UpdaterConfiguration Read();
    }
}
