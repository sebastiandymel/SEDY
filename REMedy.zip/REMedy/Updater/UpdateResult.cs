﻿namespace Updater
{
    public enum UpdateResult
    {
        WrongFile,
        UserStopped,
        Success
    }
}
