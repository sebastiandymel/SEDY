﻿namespace Remedy.Core
{
    public interface IDataItem
    {
        string Value { get; set; }
        string LocalizedName { get; set; }
    }
}