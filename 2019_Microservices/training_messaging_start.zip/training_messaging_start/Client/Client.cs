﻿using System;
using System.Threading;
using System.Threading.Tasks;
using MassTransit;

namespace Client
{
    public class Client
    {
        private readonly object _consoleLock = new object();
        private readonly Random _r = new Random();

        public async Task Execute(CancellationToken cancellationToken)
        {
            WriteLineInColor("Starting Client", ConsoleColor.DarkGreen);
        }
        public void WriteLineInColor(string msg, ConsoleColor color)
        {
            lock (_consoleLock)
            {
                Console.ForegroundColor = color;
                Console.WriteLine(msg);
                Console.ResetColor();
            }
        }
    }
}