﻿using System;
using System.Threading;
using System.Threading.Tasks;
using BasketContracts;
using BasketTracking;
using MassTransit;
using MassTransit.Saga;

namespace Basket
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("Starting...");
            await new RabbitMQBus().Execute(CancellationToken.None);
            //await new ServiceBusBus().Execute(CancellationToken.None);
        }
    }
}